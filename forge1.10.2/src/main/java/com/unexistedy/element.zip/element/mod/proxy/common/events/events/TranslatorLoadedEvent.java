package com.unexistedy.element.mod.proxy.common.events.events;

import net.minecraftforge.fml.common.eventhandler.Event;

public class TranslatorLoadedEvent extends Event{
}
