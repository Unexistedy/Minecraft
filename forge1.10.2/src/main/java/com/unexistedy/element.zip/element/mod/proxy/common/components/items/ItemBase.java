package com.unexistedy.element.mod.proxy.common.components.items;

import com.unexistedy.element.mod.proxy.common.components.IRegisterBase;
import com.unexistedy.element.mod.proxy.common.components.IRegisterModel;
import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;

public class ItemBase extends Item implements IRegisterModel<Item> {
    public ItemBase(String name){

    }
    @Override
    public IRegisterBase[] getComponents() {
        return new IRegisterBase[0];
    }

    @Override
    public void register(RegistryEvent.Register event) {

    }

    @Override
    public void registerModel() {

    }
}
