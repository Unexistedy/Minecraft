package com.unexistedy.element.mod.proxy.common.components.items;

import com.unexistedy.element.mod.proxy.common.components.IHandlerBase;
import com.unexistedy.element.mod.proxy.common.components.IRegisterBase;
import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.List;

@Mod.EventBusSubscriber
public class ItemHandler implements IHandlerBase<Item> {
    private static List<IRegisterBase<Item>> Components;

    @Override
    public void loadComponents() {

    }

    @Override
    public void uninstalComponents() {

    }

    @Override
    public void add(Item component) {

    }

    @SubscribeEvent
    public static void onRegisteryItemEvent(RegistryEvent.Register<Item> event){

    }

    @Override
    public void registerModel() {

    }

    @Override
    public void interact(Object... parameters) {

    }


    @Override
    public IRegisterBase[] getComponents() {
        return Components.toArray(new IRegisterBase[Components.size()]);
    }

    @Override
    public void register(RegistryEvent.Register event) {

    }
}
