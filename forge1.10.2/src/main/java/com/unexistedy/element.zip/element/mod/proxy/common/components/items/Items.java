package com.unexistedy.element.mod.proxy.common.components.items;

import com.unexistedy.element.mod.reference.Reference;
import net.minecraftforge.fml.common.registry.GameRegistry;

@GameRegistry.ObjectHolder(Reference.ID)
public class Items {
}
