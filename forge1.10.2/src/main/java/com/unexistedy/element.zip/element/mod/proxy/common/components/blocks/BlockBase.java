package com.unexistedy.element.mod.proxy.common.components.blocks;


import com.unexistedy.element.mod.proxy.common.components.IRegisterBase;
import com.unexistedy.element.mod.proxy.common.components.IRegisterModel;
import net.minecraft.block.Block;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraftforge.event.RegistryEvent;

public class BlockBase extends Block implements IRegisterModel<Block> {

    public BlockBase(Material blockMaterialIn, MapColor blockMapColorIn) {
        super(blockMaterialIn, blockMapColorIn);
    }

    @Override
    public IRegisterBase[] getComponents() {
        return new IRegisterBase[0];
    }

    @Override
    public void register(RegistryEvent.Register event) {

    }

    @Override
    public void registerModel() {

    }
}
