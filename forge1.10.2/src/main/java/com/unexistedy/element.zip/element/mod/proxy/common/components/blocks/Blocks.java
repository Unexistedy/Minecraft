package com.unexistedy.element.mod.proxy.common.components.blocks;

import com.unexistedy.element.mod.reference.Reference;
import net.minecraftforge.fml.common.registry.GameRegistry;

@GameRegistry.ObjectHolder(Reference.ID)
public class Blocks {
}
