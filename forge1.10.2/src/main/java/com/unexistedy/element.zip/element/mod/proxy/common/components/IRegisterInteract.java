package com.unexistedy.element.mod.proxy.common.components;

public interface IRegisterInteract extends IRegisterBase {
    void interact(Object...parameters);
}
