package com.unexistedy.element.mod.proxy;

import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

public class ClientProxy extends CommonProxy {
    @Override
    public void preInitialize(FMLPreInitializationEvent event) {
        super.preInitialize(event);
    }

    @Override
    public void initialize(FMLInitializationEvent event) {
        super.initialize(event);
    }

    @Override
    public void postInitialize(FMLPostInitializationEvent event) {
        super.postInitialize(event);
    }
}
