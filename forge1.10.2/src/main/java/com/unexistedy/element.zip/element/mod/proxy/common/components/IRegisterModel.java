package com.unexistedy.element.mod.proxy.common.components;

import net.minecraft.item.Item;
import net.minecraftforge.fml.common.registry.IForgeRegistryEntry;

public interface IRegisterModel<T extends IForgeRegistryEntry<T>> extends IRegisterBase {
    void registerModel();
}
