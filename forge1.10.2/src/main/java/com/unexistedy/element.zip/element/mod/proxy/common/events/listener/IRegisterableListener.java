package com.unexistedy.element.mod.proxy.common.events.listener;

public interface IRegisterableListener {void register();
}
